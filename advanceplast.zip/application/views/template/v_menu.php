<?php
$title = '';
$title .= 'Advanceplast';
?>
<div id="fh5co-page">
<header id="fh5co-header" role="banner">
	<div class="container">
		<div class="header-inner">
			<h1><a href="<?php echo base_url().''?>"><?= $title?><span>.</span></a></h1>
			<nav role="navigation">
				<ul>
					<li><a href="<?php echo base_url().''?>">Home</a></li>
					<li><a href="<?php echo base_url().'about'?>">About</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Product</a></li>
					<li><a href="<?php echo base_url().'artikel'?>">Blog</a></li>
					<li><a href="<?php echo base_url().'kontak'?>">Contact</a></li>
				</ul>
			</nav>
		</div>
	</div>
</header>